
import matplotlib.pyplot as plt

#data 

subjects = ["python","Java","SQL","Power BI"]
students = [40,30,20,10]

#create pie chart 
plt.pie(students,labels =  subjects)
plt.title("Students Enrolled")
plt.show()
