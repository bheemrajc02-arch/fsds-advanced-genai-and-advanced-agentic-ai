import numpy as np
import matplotlib.pyplot as plt
import pandas as pd 

dataset = pd.read_csv(r"D:\DataScience_Prakash_Senapathi\ML_Practicals\Salary_Data.csv")

X = dataset.iloc[:,:-1]
Y = dataset.iloc[:,-1]

from sklearn.model_selection import train_test_split

X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y,train_size=0.8, test_size=0.2, random_state=0 )

# Trianing the model with linear regression
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(X_train, Y_train)

#Now we need to test the model accuracy by passing x-test
y_pred = regressor.predict(X_test) 

#: Note: We need to compare y-test and Y-pred 
plt.scatter(X_test, Y_test, color='red')
plt.plot(X_train,regressor.predict(X_train),color='blue' )
plt.title('Salary vs Experience(Test Set)')
plt.xlabel('Years of experience')
plt.ylabel('Salary')
plt.show()

# in this dataset ends with 10 years per suppose if we want to predict future data 
# First we nee to calculate the coefficient and intercept 

m_coef = regressor.coef_
print(m_coef)

c_intercept = regressor.intercept_
print(c_intercept)

# Now if we want to predict salry for 12 years experience then
y12 = m_coef*12+c_intercept
print(y12)

# Now if we want to predict salry for 20 years experience then
y20 = m_coef*20+c_intercept
print(y20)
#In Machine learning the train the data is nothing but X-train and Y-train in Machine learning this is called Bias(All training section is called bias)
#Note : When we train the data the bias score will generate
#This is called training score
bias_score = regressor.score(X_train, Y_train)
print(bias_score)
#This si called testing score
variance_score = regressor.score(X_test, Y_test)
print(variance_score)

# Statistics implemetation with this  ML model

# Mean 
dataset.mean() 
dataset['Salary'].mean()
dataset['YearsExperience'].mean()

# Median 
dataset.median() 
dataset['Salary'].median()
dataset['YearsExperience'].median()

# Median 
dataset.var() 
dataset['Salary'].var()
dataset['YearsExperience'].var()

# std 
dataset.std() 
dataset['Salary'].std()
dataset['YearsExperience'].std()

# Scipy is nothing but scientific python library 
#The variation compare the 2 attributes
from scipy.stats import variation
variation(dataset.values)
variation(dataset['Salary'])
variation(dataset['YearsExperience'])

# Relation between 2 attributes employee experience and 
#employee slary is a correlation experience increases salary increases
# The range of correlation is -1 to 1  the -1 to 0 is negative correlation and 
# 0 to 1 is positive correlation
dataset.corr()

dataset['Salary'].corr(dataset['YearsExperience'])
dataset['Salary'].corr(dataset['Salary'])

dataset.skew()
dataset.sem()

import scipy.stats as stats


dataset.apply(stats.zscore)

stats.zscore(dataset[['Salary']])

#Annova Frame Work SSR,SSE,SST
# In SSR Actual,Predicted,Average

y_mean = np.mean(Y)
SSR = np.sum((y_pred-y_mean)**2)  # predicted-Average SSR
print(SSR)

y = Y[0:6]
SSE = np.sum((y-y_pred)**2) #Actual-predicted
print(SSE)

mean_total = np.mean(dataset.values)
SST = np.sum((dataset.values-mean_total)**2)
print(SST)

r_square = 1-(SSR/SST)
r_square

print(r_square)
print(bias_score)
print(variance_score)



