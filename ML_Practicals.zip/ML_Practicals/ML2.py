# -*- coding: utf-8 -*-
"""
Created on Sun Sep 27 19:58:48 2026

@author: bheem
"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

dataset = pd.read_csv(r"D:\DataScience_Prakash_Senapathi\ML_Practicals\Data.csv")

X = dataset.iloc[:,:-1].values   # here iloc means index location
Y = dataset.iloc[:,3].values

#sklearn fill the missing numerical values by default mean
from sklearn.impute import SimpleImputer
imputer = SimpleImputer()

imputer = imputer.fit(X[:,1:3])
X[:,1:3] = imputer.transform(X[:,1:3])

#sklearn fill the missing numerical values
from sklearn.impute import SimpleImputer
imputer = SimpleImputer(missing_values=np.nan, strategy="median")

imputer = imputer.fit(X[:,1:3])
X[:,1:3] = imputer.transform(X[:,1:3])


#sklearn fill the missing wih mode strategy 
from sklearn.impute import SimpleImputer
imputer = SimpleImputer(missing_values=np.nan, strategy="most_frequent")

imputer = imputer.fit(X[:,1:3])
X[:,1:3] = imputer.transform(X[:,1:3])

from sklearn.preprocessing import LabelEncoder

labelencoder_X = LabelEncoder()
labelencoder_X.fit_transform(X[:, 0])
X[:, 0] = labelencoder_X.fit_transform(X[:, 0])

labelencoder_Y = LabelEncoder()
Y = labelencoder_Y.fit_transform(Y)

from sklearn.model_selection import train_test_split

X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y,train_size=0.8, test_size=0.2, random_state=0 )


X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y,train_size=0.7, test_size=0.3, random_state=0 )















