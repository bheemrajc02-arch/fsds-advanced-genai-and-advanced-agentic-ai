import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset using a relative path
dataset = pd.read_csv('student_info.csv')

# Split the data into independent and dependent variables
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, 1].values

# By default header will print only first 5 rows
print(dataset.head())
# By default header will print only last 5 rows
print(dataset.tail())
# Prints no of rows and columns
print(dataset.shape)

print(dataset.info())

print(dataset.describe())

# plt.scatter(x =dataset.study_hours, y = dataset.student_marks)
# plt.xlabel("Students Study Hours")
# plt.ylabel("Students marks")
# plt.title("Scatter Plot of Students Study Hours vs Students marks")
# plt.show()
# plt.close()

# Plot and save the scatter plot without blocking code execution
plt.scatter(x=dataset.study_hours, y=dataset.student_marks)
plt.xlabel("Students Study Hours")
plt.ylabel("Students marks")
plt.title("Scatter Plot of Students Study Hours vs Students marks")

# Save the plot as an image file in your folder
plt.savefig("study_hours_plot.png")

# Close the plot figure to free up memory and let the script continue
plt.close()

# preparing the data for the machine learning algorithm 
# datacleaning 
print(dataset.isnull().sum())

print(dataset.mean())

# Fill missing values with the column mean
dataset.fillna(dataset.mean(), inplace=True)

# Verify that all missing values have been filled (should all be 0 now)
print("\n--- Missing Values After Filling ---")
print(dataset.isnull().sum())

# Split the data into independent and dependent variables
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, 1].values

# Split the data into independent (X) and dependent (y) variables
X = dataset.drop("student_marks", axis="columns")
y = dataset.drop("study_hours", axis="columns")

# Print the shapes to verify
print("shape of X = ", X.shape)
print("shape of y = ", y.shape)

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=51)

print("shape of X_train = ", X_train.shape)
print("shape of y_train = ", y_train.shape)
print("shape of X_test = ", X_test.shape)
print("shape of y_test = ", y_test.shape)

from sklearn.linear_model import LinearRegression
lr = LinearRegression()

lr.fit(X_train,y_train)

lr.coef_
lr.intercept_
print("Coefficient Value : ", lr.coef_)
print("intercept_ Value : ", lr.intercept_)

print("Predicted marks for 4 hours:", lr.predict([[4]])[0][0].round(2))

# Make predictions on test set
y_pred = lr.predict(X_test)
print("\n--- Predictions Array ---")
print(y_pred)


# Create comparison dataframe
comparison_df = pd.DataFrame(
    np.c_[X_test, y_test, y_pred], 
    columns=["study_hours", "student_marks_original", "student_marks_predicted"]
)
print("\n--- Comparison DataFrame ---")
print(comparison_df)

# Fine Tuning / Model Score
print("\nModel Score (R^2):", lr.score(X_test, y_test))


plt.scatter(X_train, y_train, color="blue", label="Train Data")
plt.scatter(X_test, y_test, color="green", label="Test Data")
plt.plot(X_train, lr.predict(X_train), color="r", label="Regression Line")
plt.xlabel("Students Study Hours")
plt.ylabel("Students Marks")
plt.title("Linear Regression Fit")
plt.legend()

# Save and close the plot so execution completes cleanly
plt.savefig("linear_regression_results.png")
plt.close()
print("\nPlot saved successfully as 'linear_regression_results.png'!")

import joblib
joblib.dump(lr, "student_mark_predictor.pkl")
model = joblib.load("student_mark_predictor.pkl")
model.predict([[5]])[0][0]