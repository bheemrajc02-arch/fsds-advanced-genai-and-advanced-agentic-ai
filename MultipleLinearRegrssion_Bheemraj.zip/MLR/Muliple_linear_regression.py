import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

dataset = pd.read_csv(r"D:\DataScience_Prakash_Senapathi\Multiple_Linear_Regression\6th - mlr\6th - mlr\MLR\Investment.csv")

# Use a uppercase 'Y' to match later standard practice or stay consistent.
# For this example, we will stick with uppercase 'Y' to fix the script.
X = dataset.iloc[:, :-1]
Y = dataset.iloc[:, 4]  # <-- Correted from 'y' to 'Y'

# In the dataset we have text for state column we cannot train text
# so we are converting in to numbers instead of using encoder we are using dummies
X = pd.get_dummies(X, dtype=int)

from sklearn.model_selection import train_test_split

# All variable names are now consistent (Y, Y_train, Y_test)
X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, train_size=0.8, random_state=0
)

# Training the model with linear regression
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(X_train, Y_train)

# Now we need to test the model accuracy by passing x-test
y_pred = regressor.predict(X_test) 


# we get 6 cofficients because the state are converting in to dummy variable
m_coef = regressor.coef_
print("Coefficients:", m_coef)

c_intercept = regressor.intercept_
print("Intercept:", c_intercept)

# we are adding this constant to each and every record 
X = np.append( arr=np.full((50, 1), 1).astype(int), values=X, axis=1)

# we got slope and interceptor  Now as per our requirement we need to remove some attributes that is called feature elimination
# And we need to give the best to organization in order to do this we are introduced the stats.api
# api has recursive feature elimination We are using statistical model to eliminate the feature 
#which has lowest p value
import statsmodels.api as sm
X_opt = X[:, [0, 1, 2, 3, 4, 5]]
# Ordinary Least Squares
regressor_OLS = sm.OLS(endog=Y, exog=X_opt).fit()
regressor_OLS.summary()

# P value of x4 is 0.990 which is greater than 0.5 so we need to eliminate the null hypothesis it
# which can be done by removing index 4 and rerun code
 
import statsmodels.api as sm
X_opt = X[:, [0, 1, 2, 3, 5]]
# Ordinary Least Squares
regressor_OLS = sm.OLS(endog=Y, exog=X_opt).fit()
regressor_OLS.summary()


# P value of x5 is 0.940 which is greater than 0.5 so we need to eliminate the null hypothesis it
# which can be done by removing index 5 and rerun code

import statsmodels.api as sm
X_opt = X[:, [0, 1, 2, 3]]
# Ordinary Least Squares
regressor_OLS = sm.OLS(endog=Y, exog=X_opt).fit()
regressor_OLS.summary()
 
# After removing 4 and 5 index X2 has P value of x2 is 0.602 which is greater than 0.5 so we need to eliminate the null hypothesis it
# which can be done by removing index 5 and rerun code


import statsmodels.api as sm
X_opt = X[:, [0, 1,3]]
# Ordinary Least Squares
regressor_OLS = sm.OLS(endog=Y, exog=X_opt).fit()
regressor_OLS.summary()

import statsmodels.api as sm
X_opt = X[:, [0, 1]]
# Ordinary Least Squares
regressor_OLS = sm.OLS(endog=Y, exog=X_opt).fit()
regressor_OLS.summary()

#Finally we are suggesting the organization to invest money on digital marketing because leads will create and more sales will happen 
#This is called recursive elimination feature elimination or recursive elimination in machine learning we are eliminating attributes
# based on P value if the model geerate the P value grater than 0.5 then we reject the null hypotesis
# The Reject null hypothesis in statistic is equal to eliminate the attributes in machine Learning 


#This is called training score#This is called training score
bias_score = regressor.score(X_train, Y_train)
print(bias_score)
#This si called testing score
variance_score = regressor.score(X_test, Y_test)
print(variance_score)

#Note : In simple linear regression we will predict feature where as in the multiple linear regression we are target 
#which is right attribute



#Assume we are working in a stock market in world multiple stock is there which stock 
#we want to buy which stock performance is good we can do multiple linear regression by calling recursive elimination or feature elimination 

