# -*- coding: utf-8 -*-
"""
Created on Tue Jul  7 22:59:48 2026

@author: bheem
"""
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 1. Use read_csv for a .csv file
dataset = pd.read_csv(r"D:\DataScience_Prakash_Senapathi\Investment\Investment.csv")

# Takes all columns except the last one
X = dataset.iloc[:, :-1]

# 2. Keep this as -1 to get the very last column
y = dataset.iloc[:, 4]


X = pd.get_dummies(X,dtype=int)


from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y, test_size = 0.2,random_state = 0)


from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(X_train, y_train)

y_pred = regressor.predict(X_test)

m = regressor.coef_
print(m)

c = regressor.intercept_
print(c)

X = np.append(arr = np.full((50,1), 42467).astype(int), values=X, axis =1)

import statsmodels.api as sm
X_opt = X[:,[0,1,2,3,4,5]]
regressor_OLS = sm.OLS(endog=y, exog=X_opt).fit()
regressor_OLS.summary()

print(regressor_OLS.summary())








