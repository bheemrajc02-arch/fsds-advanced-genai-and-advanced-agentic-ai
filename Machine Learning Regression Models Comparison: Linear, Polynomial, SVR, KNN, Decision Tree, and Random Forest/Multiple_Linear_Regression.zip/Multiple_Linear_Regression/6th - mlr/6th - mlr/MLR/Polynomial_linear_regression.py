import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Load dataset
dataset = pd.read_csv(r"D:\DataScience_Prakash_Senapathi\Polynomial_Regression_Model\9th - Poly\9th - Poly\1.POLYNOMIAL REGRESSION\emp_sal.csv")

X = dataset.iloc[:, 1:2].values
Y = dataset.iloc[:, 2].values

# 1. Linear Regression Model
from sklearn.linear_model import LinearRegression
lin_reg = LinearRegression()
lin_reg.fit(X, Y)

lin_model_pred = lin_reg.predict([[6.5]])
print("Linear Model Prediction:", lin_model_pred)

# 2. Polynomial Regression Model (Degree 4)
from sklearn.preprocessing import PolynomialFeatures
poly_reg = PolynomialFeatures(degree=4)
X_poly = poly_reg.fit_transform(X)

lin_reg_2 = LinearRegression()
lin_reg_2.fit(X_poly, Y)

print("Linear Regression object:", lin_reg)
print("Polynomial Features object:", poly_reg)
print("Linear Regression (Polynomial) object:", lin_reg_2)

# Polynomial regression visualization
plt.scatter(X, Y, color='red')
plt.plot(X, lin_reg_2.predict(X_poly), color='blue')
plt.title('Polynomial Regression graph')
plt.xlabel('Position level')
plt.ylabel('Salary')
plt.show()

# Predictions
lin_model_pred = lin_reg.predict([[6.5]])
print("Linear Model Prediction for 6.5:", lin_model_pred)

poly_model_pred = lin_reg_2.predict(poly_reg.transform([[6.5]]))
print("Polynomial Model Prediction for 6.5:", poly_model_pred)

# 3. SVR Model (kernel='sigmoid')
from sklearn.svm import SVR
svr_regressor = SVR(kernel='sigmoid', degree=3, gamma='scale')
svr_regressor.fit(X, Y)

svr_model_pred = svr_regressor.predict([[6.5]])
print("SVR (sigmoid) Prediction for 6.5:", svr_model_pred)

# 4. SVR Model (kernel='poly', gamma='auto')
svr_regressor_poly = SVR(kernel='poly', degree=4, gamma='auto')
svr_regressor_poly.fit(X, Y)

svr_model_pred_poly = svr_regressor_poly.predict([[6.5]])
print("SVR (poly) Prediction for 6.5:", svr_model_pred_poly)

# 5. K-Neighbors Regressor
from sklearn.neighbors import KNeighborsRegressor
knn_regressor = KNeighborsRegressor(n_neighbors=4,weights='distance',p=2)
knn_regressor.fit(X, Y)
knn_model_predict = knn_regressor.predict([[6.5]])
print("KNN Prediction for 6.5:", knn_model_predict)

# 5. K-Neighbors Regressor 
from sklearn.neighbors import KNeighborsRegressor
knn_regressor = KNeighborsRegressor(n_neighbors=4,weights='uniform',p=1)
knn_regressor.fit(X, Y)
knn_model_predict = knn_regressor.predict([[6.5]])
print("KNN Prediction for 6.5:", knn_model_predict)


# 5. K-Neighbors Regressor 
from sklearn.neighbors import KNeighborsRegressor
knn_regressor = KNeighborsRegressor(n_neighbors=5,weights='uniform',p=1)
knn_regressor.fit(X, Y)
knn_model_predict = knn_regressor.predict([[6.5]])
print("KNN Prediction for 6.5:", knn_model_predict)

# 5. K-Neighbors Regressor 
from sklearn.neighbors import KNeighborsRegressor
knn_regressor = KNeighborsRegressor(n_neighbors=2,algorithm='brute')
knn_regressor.fit(X, Y)
knn_model_predict = knn_regressor.predict([[6.5]])
print("KNN Prediction for 6.5:", knn_model_predict)

# TREE Algorithm this tree algorithm in ML called as CART and CA-classification
# and RT for regression  
from sklearn.tree import DecisionTreeRegressor
dt_regreesor = DecisionTreeRegressor()
dt_regreesor.fit(X,Y)
dt_model_predict = dt_regreesor.predict([[6.5]])
print("Decision TREE Prediction for 6.5:", dt_model_predict)

# Random Forest with out adding random state to zero
from sklearn.ensemble import RandomForestRegressor
rf_ref = RandomForestRegressor()
rf_ref.fit(X,Y)
rf_model_predict = rf_ref.predict([[6.5]])
print("Random Forest Prediction for 6.5:",rf_model_predict)

# Random Forest with  adding random state to zero
from sklearn.ensemble import RandomForestRegressor
rf_ref = RandomForestRegressor(random_state=0,n_estimators=30)
rf_ref.fit(X,Y)
rf_model_predict = rf_ref.predict([[6.5]])
print("Random Forest Prediction for 6.5:",rf_model_predict)


# Random Forest with  adding random state to zero
from sklearn.ensemble import RandomForestRegressor
rf_ref = RandomForestRegressor(random_state=0,n_estimators=40)
rf_ref.fit(X,Y)
rf_model_predict = rf_ref.predict([[6.5]])
print("Random Forest Prediction for 6.5:",rf_model_predict)
















